<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","","tokoonline");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>